package br.com.pizzaria.pizzaorderapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private CheckBox cbCalabresa, cbMussarela, cbFrango;
    private Button btnProximo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cbCalabresa = findViewById(R.id.cbCalabresa);
        cbMussarela = findViewById(R.id.cbMussarela);
        cbFrango = findViewById(R.id.cbFrango);
        btnProximo = findViewById(R.id.btnProximo);

        btnProximo.setOnClickListener(v -> {
            ArrayList<String> tiposPizza = new ArrayList<>();
            if (cbCalabresa.isChecked()) tiposPizza.add("Calabresa");
            if (cbMussarela.isChecked()) tiposPizza.add("Mussarela");
            if (cbFrango.isChecked()) tiposPizza.add("Frango");

            if (tiposPizza.isEmpty()) {
                cbCalabresa.setError("Selecione pelo menos uma pizza");
                return;
            }

            Intent intent = new Intent(MainActivity.this, SizePaymentActivity.class);
            intent.putStringArrayListExtra("TIPOS_PIZZA", tiposPizza);
            startActivity(intent);
        });
    }
}