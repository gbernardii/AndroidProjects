package br.com.pizzaria.pizzaorderapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class SizePaymentActivity extends AppCompatActivity {
    private RadioGroup rgTamanho, rgPagamento;
    private Button btnConfirmar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_size_payment);

        rgTamanho = findViewById(R.id.rgTamanho);
        rgPagamento = findViewById(R.id.rgPagamento);
        btnConfirmar = findViewById(R.id.btnConfirmar);

        ArrayList<String> tiposPizza = getIntent().getStringArrayListExtra("TIPOS_PIZZA");

        btnConfirmar.setOnClickListener(v -> {
            String tamanho = "";
            double precoBase = 0.0;
            int selectedTamanhoId = rgTamanho.getCheckedRadioButtonId();
            if (selectedTamanhoId == R.id.rbPequena) {
                tamanho = "Pequena";
                precoBase = 20.00;
            } else if (selectedTamanhoId == R.id.rbMedia) {
                tamanho = "Média";
                precoBase = 30.00;
            } else if (selectedTamanhoId == R.id.rbGrande) {
                tamanho = "Grande";
                precoBase = 40.00;
            }

            String pagamento = "";
            int selectedPagamentoId = rgPagamento.getCheckedRadioButtonId();
            if (selectedPagamentoId == R.id.rbDinheiro) {
                pagamento = "Dinheiro";
            } else if (selectedPagamentoId == R.id.rbCartao) {
                pagamento = "Cartão";
            }

            double total = precoBase * tiposPizza.size(); // Cada tipo de pizza multiplica o preço base

            Intent intent = new Intent(SizePaymentActivity.this, OrderSummaryActivity.class);
            intent.putStringArrayListExtra("TIPOS_PIZZA", tiposPizza);
            intent.putExtra("TAMANHO", tamanho);
            intent.putExtra("PAGAMENTO", pagamento);
            intent.putExtra("TOTAL", total);
            startActivity(intent);
        });
    }
}