package br.com.pizzaria.pizzaorderapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class OrderSummaryActivity extends AppCompatActivity {
    private TextView tvResumo;
    private Button btnNovoPedido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_summary);

        tvResumo = findViewById(R.id.tvResumo);
        btnNovoPedido = findViewById(R.id.btnNovoPedido);

        ArrayList<String> tiposPizza = getIntent().getStringArrayListExtra("TIPOS_PIZZA");
        String tamanho = getIntent().getStringExtra("TAMANHO");
        String pagamento = getIntent().getStringExtra("PAGAMENTO");
        double total = getIntent().getDoubleExtra("TOTAL", 0.0);

        StringBuilder resumo = new StringBuilder();
        resumo.append("Tipos de Pizza: ").append(String.join(", ", tiposPizza)).append("\n");
        resumo.append("Tamanho: ").append(tamanho).append("\n");
        resumo.append("Pagamento: ").append(pagamento).append("\n");
        resumo.append(String.format("Total: R$ %.2f", total));

        tvResumo.setText(resumo.toString());

        btnNovoPedido.setOnClickListener(v -> {
            Intent intent = new Intent(OrderSummaryActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });
    }
}